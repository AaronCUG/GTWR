#!/usr/bin/env python3
"""Empirically audit whether analytical Lon/Lai behave as WGS84 coordinates.

The source workbook does not carry CRS metadata.  This diagnostic compares the
reported county coordinates, and standard inverse transforms from GCJ-02 and
BD-09, with the author-supplied WGS84 county polygons.  Polygon centroids are
only a reference (the reported points need not be centroids), so the result is
reported as an empirical consistency check rather than proof of provenance.
"""

from __future__ import annotations

import json
import math
from pathlib import Path

import geopandas as gpd
import numpy as np
import pandas as pd
from pyproj import Geod
from shapely.geometry import Point

ROOT = Path("/Users/lizhaojie/Desktop/working")
PANEL = ROOT / "gtwr_metric_v15_20260726/data/full_experiment_panel_std_supplemented.csv"
PACK = ROOT / "张楷涛论文_Mac代码制图包_v15_米制GTWR_20260726"
COUNTY = PACK / "source_data/admin_author_2020_candidate/county/县级.shp"
CROSSWALK = PACK / "qc/analysis_to_map_crosswalk.csv"
OUT = ROOT / "gtwr_metric_v15_20260726/coordinate_crs_diagnostic"
AEQD = "+proj=aeqd +lat_0=35 +lon_0=105 +datum=WGS84 +units=m +no_defs"

A = 6378245.0
EE = 0.00669342162296594323


def outside_china(lon: float, lat: float) -> bool:
    return not (72.004 <= lon <= 137.8347 and 0.8293 <= lat <= 55.8271)


def transform_lat(x: float, y: float) -> float:
    ret = -100.0 + 2.0*x + 3.0*y + 0.2*y*y + 0.1*x*y + 0.2*math.sqrt(abs(x))
    ret += (20.0*math.sin(6.0*x*math.pi) + 20.0*math.sin(2.0*x*math.pi))*2.0/3.0
    ret += (20.0*math.sin(y*math.pi) + 40.0*math.sin(y/3.0*math.pi))*2.0/3.0
    ret += (160.0*math.sin(y/12.0*math.pi) + 320*math.sin(y*math.pi/30.0))*2.0/3.0
    return ret


def transform_lon(x: float, y: float) -> float:
    ret = 300.0 + x + 2.0*y + 0.1*x*x + 0.1*x*y + 0.1*math.sqrt(abs(x))
    ret += (20.0*math.sin(6.0*x*math.pi) + 20.0*math.sin(2.0*x*math.pi))*2.0/3.0
    ret += (20.0*math.sin(x*math.pi) + 40.0*math.sin(x/3.0*math.pi))*2.0/3.0
    ret += (150.0*math.sin(x/12.0*math.pi) + 300.0*math.sin(x/30.0*math.pi))*2.0/3.0
    return ret


def wgs_to_gcj(lon: float, lat: float) -> tuple[float, float]:
    if outside_china(lon, lat):
        return lon, lat
    dlat = transform_lat(lon - 105.0, lat - 35.0)
    dlon = transform_lon(lon - 105.0, lat - 35.0)
    radlat = lat / 180.0 * math.pi
    magic = math.sin(radlat)
    magic = 1 - EE * magic * magic
    sqrtmagic = math.sqrt(magic)
    dlat = (dlat * 180.0) / ((A * (1 - EE)) / (magic * sqrtmagic) * math.pi)
    dlon = (dlon * 180.0) / (A / sqrtmagic * math.cos(radlat) * math.pi)
    return lon + dlon, lat + dlat


def gcj_to_wgs(lon: float, lat: float) -> tuple[float, float]:
    glon, glat = wgs_to_gcj(lon, lat)
    return lon * 2 - glon, lat * 2 - glat


def bd_to_gcj(lon: float, lat: float) -> tuple[float, float]:
    x = lon - 0.0065
    y = lat - 0.006
    z = math.sqrt(x*x + y*y) - 0.00002 * math.sin(y * math.pi * 3000.0 / 180.0)
    theta = math.atan2(y, x) - 0.000003 * math.cos(x * math.pi * 3000.0 / 180.0)
    return z * math.cos(theta), z * math.sin(theta)


def bd_to_wgs(lon: float, lat: float) -> tuple[float, float]:
    return gcj_to_wgs(*bd_to_gcj(lon, lat))


def main() -> None:
    panel = pd.read_csv(PANEL, dtype={"Code": str})[["Code", "Lon", "Lai"]].drop_duplicates("Code")
    cross = pd.read_csv(CROSSWALK, dtype={"SOURCE_CODE": str, "MAP_CODE": str})
    cross = cross[cross["METHOD"].eq("exact_code") & ~cross["PREVIEW_ONLY"].astype(str).str.lower().eq("true")]
    g = gpd.read_file(COUNTY)[["code", "geometry"]].rename(columns={"code": "MAP_CODE"})
    g["MAP_CODE"] = g["MAP_CODE"].astype(str).str.replace(r"\.0$", "", regex=True).str.zfill(6)
    g = g.drop_duplicates("MAP_CODE")
    cent = g.to_crs(AEQD)
    cent["geometry"] = cent.geometry.centroid
    cent = cent.to_crs("EPSG:4326")
    cent["centroid_lon"] = cent.geometry.x
    cent["centroid_lat"] = cent.geometry.y
    merged = panel.merge(cross[["SOURCE_CODE", "MAP_CODE"]], left_on="Code", right_on="SOURCE_CODE", validate="one_to_one")
    merged = merged.merge(cent[["MAP_CODE", "centroid_lon", "centroid_lat"]], on="MAP_CODE", validate="many_to_one")
    polygon = g.set_index("MAP_CODE").geometry
    geod = Geod(ellps="WGS84")

    candidates = {
        "as_WGS84": lambda x, y: (x, y),
        "as_GCJ02_then_to_WGS84": gcj_to_wgs,
        "as_BD09_then_to_WGS84": bd_to_wgs,
    }
    rows = []
    details = merged[["Code", "MAP_CODE", "Lon", "Lai", "centroid_lon", "centroid_lat"]].copy()
    for name, fn in candidates.items():
        xy = np.array([fn(float(x), float(y)) for x, y in zip(merged["Lon"], merged["Lai"])])
        _, _, dist = geod.inv(xy[:, 0], xy[:, 1], merged["centroid_lon"], merged["centroid_lat"])
        inside = np.array([
            polygon.loc[code].covers(Point(lon, lat))
            for code, lon, lat in zip(merged["MAP_CODE"], xy[:, 0], xy[:, 1])
        ])
        details[f"{name}_lon"] = xy[:, 0]
        details[f"{name}_lat"] = xy[:, 1]
        details[f"{name}_centroid_km"] = dist / 1000.0
        details[f"{name}_inside"] = inside
        rows.append({
            "interpretation": name,
            "n_exact_code_units": int(len(merged)),
            "inside_polygon_pct": float(inside.mean() * 100),
            "centroid_distance_mean_km": float(np.mean(dist) / 1000),
            "centroid_distance_median_km": float(np.median(dist) / 1000),
            "centroid_distance_p95_km": float(np.quantile(dist, .95) / 1000),
        })
    summary = pd.DataFrame(rows).sort_values("centroid_distance_mean_km")
    OUT.mkdir(parents=True, exist_ok=True)
    summary.to_csv(OUT / "coordinate_interpretation_comparison.csv", index=False)
    details.to_csv(OUT / "coordinate_interpretation_details.csv", index=False)
    payload = {
        "source_crs_metadata_found": False,
        "comparison": rows,
        "interpretation_rule": (
            "Lower centroid distance and higher within-polygon rate indicate greater consistency; "
            "because analytical points need not be polygon centroids, this is not definitive CRS provenance."
        ),
    }
    (OUT / "coordinate_crs_diagnostic.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
