#!/usr/bin/env python3
"""All-target Wheeler/PySAL-style condition-index and VDP audit.

The design matches ``06_pysal_style_local_cn.py``: globally z-standardised
fifteen predictors plus an intercept, multiplied by the fixed-Gaussian kernel
weights and column L2-normalised.  For the largest-condition-index dimension,
variance-decomposition proportions (VDPs) are calculated for every term.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from pyproj import CRS, Transformer
from scipy.spatial import cKDTree


PROJ4 = "+proj=aeqd +lat_0=35 +lon_0=105 +datum=WGS84 +units=m +no_defs"
X15 = [
    "X1", "X2", "TRDEP", "X7", "RESH", "X16", "X9", "X10", "X11",
    "X13", "X14", "X3", "X4", "X8", "X6",
]
TERMS = ["intercept", *X15]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--local", type=Path, required=True)
    parser.add_argument("--pysal-cn-detail", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--bw-km", type=float, default=200.0)
    parser.add_argument("--temporal-years", type=float, default=1.5)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    raw = pd.read_csv(args.input, dtype={"Code": str})
    cols = ["Code", "Year", "ActualYear", "Lon", "Lai", "URP_clean", *X15]
    d = raw[cols].replace([np.inf, -np.inf], np.nan).dropna().reset_index(drop=True)
    assert len(d) == 27_299 and d["Code"].nunique() == 2_120
    values = d[X15].to_numpy(float)
    means = values.mean(axis=0)
    sds = values.std(axis=0, ddof=0)
    assert np.all(sds > np.finfo(float).eps)
    design = np.column_stack([np.ones(len(d)), (values - means) / sds])

    transformer = Transformer.from_crs(
        "EPSG:4326", CRS.from_proj4(PROJ4), always_xy=True
    )
    x_m, y_m = transformer.transform(d["Lon"].to_numpy(), d["Lai"].to_numpy())
    bw_m = args.bw_km * 1000.0
    temporal_rate_m = bw_m / args.temporal_years
    points = np.column_stack([x_m, y_m, d["Year"].to_numpy(float) * temporal_rate_m])
    tree = cKDTree(points)

    rows: list[dict] = []
    for i in range(len(d)):
        idx = np.asarray(tree.query_ball_point(points[i], 6.0 * bw_m), dtype=int)
        distance = np.linalg.norm(points[idx] - points[i], axis=1)
        weights = np.exp(-0.5 * np.square(distance / bw_m))
        xw = design[idx] * weights[:, None]
        norms = np.sqrt(np.square(xw).sum(axis=0))
        xn = xw / norms
        _, singular, vt = np.linalg.svd(xn, full_matrices=False)
        condition = float(singular[0] / singular[-1])
        v = vt.T
        phi = np.square(v) / np.square(singular)[None, :]
        proportions = phi / phi.sum(axis=1, keepdims=True)
        largest_dimension_vdp = proportions[:, -1]
        high_count = int(np.sum(largest_dimension_vdp > 0.5))
        row = {
            "target_row": i,
            "Code": d.at[i, "Code"],
            "ActualYear": int(d.at[i, "ActualYear"]),
            "pysal_style_cn": condition,
            "largest_dimension_high_vdp_term_count": high_count,
            "cn_gt_30": bool(condition > 30),
            "joint_cn_vdp_flag": bool(condition > 30 and high_count >= 2),
        }
        row.update({f"VDP_{term}": float(value) for term, value in zip(TERMS, largest_dimension_vdp)})
        rows.append(row)
        if i and i % 5000 == 0:
            print(f"{i}/{len(d)}", flush=True)

    frame = pd.DataFrame(rows)
    external = pd.read_csv(args.pysal_cn_detail, dtype={"Code": str})
    assert len(external) == len(frame)
    assert external["Code"].equals(frame["Code"])
    assert np.array_equal(external["ActualYear"].to_numpy(), frame["ActualYear"].to_numpy())
    max_cn_error = float(
        np.max(
            np.abs(
                external["pysal_style_local_condition_number"].to_numpy(float)
                - frame["pysal_style_cn"].to_numpy(float)
            )
        )
    )
    assert max_cn_error < 1e-9, max_cn_error

    output = args.output_dir / "wheeler_vdp_joint_all_targets.csv"
    frame.to_csv(output, index=False)
    cn_flag = frame["cn_gt_30"]
    joint = frame["joint_cn_vdp_flag"]
    high_term_frequency = {
        term: int((cn_flag & frame[f"VDP_{term}"].gt(0.5)).sum()) for term in TERMS
    }
    manifest = {
        "status": "passed",
        "definition": {
            "design": "15 transformed predictors globally z-standardized within exact A_main complete cases, plus intercept",
            "weights": (
                f"fixed Gaussian GTWR weights at {args.bw_km:g} km spatial and "
                f"{args.temporal_years:g} year temporal bandwidth; diagnostic "
                "omits weights beyond six joint bandwidths (<exp(-18))"
            ),
            "condition_index": (
                "PySAL mgwr convention: X including intercept multiplied by w, "
                "columns L2-normalized, largest/smallest singular value"
            ),
            "vdp": (
                "For the smallest-singular-value/largest-condition-index dimension, "
                "(v_jk^2/s_k^2) normalized across dimensions for each term"
            ),
            "joint_flag": (
                "pysal_style_cn > 30 AND at least two model terms (intercept "
                "included) have VDP > 0.5 in the largest-condition-index dimension"
            ),
        },
        "counts": {
            "rows": int(len(frame)),
            "cn_gt_30": int(cn_flag.sum()),
            "cn_gt_30_pct": float(cn_flag.mean() * 100),
            "joint_cn_vdp_flag": int(joint.sum()),
            "joint_flag_pct": float(joint.mean() * 100),
            "codes_ever_joint_flag": int(frame.loc[joint, "Code"].nunique()),
        },
        "high_vdp_term_frequency_among_cn_flags": high_term_frequency,
        "cn_recalculation_max_abs_error": max_cn_error,
        "inputs": {
            "standardized_panel": {"path": str(args.input), "sha256": sha256(args.input)},
            "pysal_cn_detail": {"path": str(args.pysal_cn_detail), "sha256": sha256(args.pysal_cn_detail)},
            "final_local_A_main": {"path": str(args.local), "sha256": sha256(args.local)},
        },
        "output": {"path": str(output), "sha256": sha256(output)},
    }
    manifest_path = args.output_dir / "wheeler_vdp_joint_manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
