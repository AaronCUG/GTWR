#!/usr/bin/env python3
"""Evaluate AICc for one declared spatial row of the stable GTWR grid."""

from __future__ import annotations

import argparse
import importlib.util
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path("/Users/lizhaojie/Desktop/working/gtwr_metric_v15_20260726")
MODEL_SCRIPT = ROOT / "01_run_gtwr_metric.py"
INPUT = ROOT / "data/full_experiment_panel_std_supplemented.csv"
STABILITY = (
    ROOT / "bandwidth_stability_predeclared_grid" /
    "bandwidth_stability_summary.json"
)


def load_model_module():
    spec = importlib.util.spec_from_file_location("metric_gtwr", MODEL_SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError("Cannot load metric GTWR module")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bw-km", type=float, required=True)
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    stability = json.loads(STABILITY.read_text(encoding="utf-8"))
    accepted = [
        row for row in stability["summaries"]
        if float(row["bw_km"]) == args.bw_km
        and float(row["effective_n"]["min"]) >= 16.0
        and float(row["local_standardized_condition_number"]["max"]) <= 30.0
    ]
    if not accepted:
        raise RuntimeError(f"No stable predeclared candidates for {args.bw_km} km")

    module = load_model_module()
    std = pd.read_csv(INPUT, dtype={"Code": str})
    runner = module.MetricRunner(std, args.output.parent, args.threads)
    data, y_col, x_cols = runner.prep("A_main")
    rows: list[dict] = []
    for stable in accepted:
        years = float(stable["temporal_bandwidth_years"])
        rate = args.bw_km / years
        started = time.time()
        aicc = runner.cal_aicc(
            data, y_col, x_cols, args.bw_km * 1000.0, rate * 1000.0
        )
        if not np.isfinite(aicc):
            raise AssertionError((args.bw_km, years, aicc))
        row = {
            "bw_km": args.bw_km,
            "temporal_bandwidth_years": years,
            "temporal_rate_km_per_year": rate,
            "aicc": float(aicc),
            "effective_n_min_sample_audit": stable["effective_n"]["min"],
            "standardized_condition_max_sample_audit": stable[
                "local_standardized_condition_number"
            ]["max"],
            "elapsed_s": round(time.time() - started, 2),
        }
        rows.append(row)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(
            json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        print(json.dumps(row), flush=True)
    print(f"PASS: {args.output}")


if __name__ == "__main__":
    main()
