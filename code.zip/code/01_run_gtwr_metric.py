#!/usr/bin/env python3
"""Fit GTWR with a China-centred metric projection in an isolated v15 workspace.

The model uses WGS84 / Azimuthal Equidistant coordinates centred at 105E, 35N.
Coordinates passed to mgtwr are metres.  ``tau`` therefore has units of
metres squared per year squared; the search is expressed more readably as the
equivalent temporal distance rate sqrt(tau), in km per year.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import sys
import time
import warnings
from pathlib import Path

import mgtwr
import numpy as np
import pandas as pd
import pyproj
from mgtwr.diagnosis import get_AICc
from mgtwr.model import GTWR
from pyproj import CRS, Transformer
from scipy.linalg import LinAlgWarning

# A near-singular local design must stop the run instead of being silently
# accepted.  The legacy script suppressed all warnings, which hid unstable
# coefficient estimates for the locally varying county-type dummies.
warnings.filterwarnings("error", category=LinAlgWarning)

ROOT = Path("/Users/lizhaojie/Desktop/working/gtwr_metric_v15_20260726")
DEFAULT_INPUT = Path(
    "/Users/lizhaojie/Desktop/working/land_redevelopment_rerun_20260725/"
    "data/full_experiment_panel_std_supplemented.csv"
)
PROJ4 = "+proj=aeqd +lat_0=35 +lon_0=105 +datum=WGS84 +units=m +no_defs"

CONTINUOUS_X = [
    "X1", "X2", "TRDEP", "X7", "RESH", "X16", "X9", "X10", "X11",
    "X13", "X14", "X3", "X4", "X8", "X6",
]
MODELS = {
    # County type is a time-invariant, locally sparse category.  Treating its
    # two indicators as locally varying slopes made X'WX nearly singular in
    # several regions.  The main GTWR therefore estimates the fifteen
    # continuous candidate-factor surfaces; county-type heterogeneity is
    # assessed separately with county and year fixed-effects interactions.
    "A_main": ("URP_clean", CONTINUOUS_X),
    "A_dv2": ("dv2_ln_area_per_hukou", [c for c in CONTINUOUS_X if c != "X16"]),
    "A_dv3": ("dv3_ln_projects_per_hukou", [c for c in CONTINUOUS_X if c != "X16"]),
    "B_netpop": ("URP_clean", CONTINUOUS_X + ["NETPOP"]),
    "C_rei": ("URP_clean", CONTINUOUS_X + ["REI_10k"]),
}

COARSE_BW_KM = (75.0, 100.0, 125.0, 200.0)
COARSE_TEMPORAL_BW_YEARS = (1.5, 2.25, 3.0, 4.0)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(payload: object, path: Path) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


class MetricRunner:
    def __init__(self, std: pd.DataFrame, result_dir: Path, threads: int):
        self.std = std.copy()
        self.result_dir = result_dir
        self.threads = threads
        transformer = Transformer.from_crs("EPSG:4326", CRS.from_proj4(PROJ4), always_xy=True)
        x_m, y_m = transformer.transform(
            self.std["Lon"].to_numpy(float), self.std["Lai"].to_numpy(float)
        )
        self.std["X_m"] = np.asarray(x_m, dtype=float)
        self.std["Y_m"] = np.asarray(y_m, dtype=float)
        assert np.isfinite(self.std[["X_m", "Y_m"]].to_numpy()).all()

    def prep(self, model: str) -> tuple[pd.DataFrame, str, list[str]]:
        y_col, x_cols = MODELS[model]
        source = self.std
        if model == "C_rei":
            source = source[
                pd.to_numeric(source["ActualYear"], errors="coerce").le(2017)
                & ~source["Code"].astype(str).str.startswith("65")
            ]
        cols = [
            "Code", "Year", "ActualYear", "Lon", "Lai", "X_m", "Y_m",
            "CountyType", y_col,
        ] + x_cols
        d = source[cols].replace([np.inf, -np.inf], np.nan).dropna().reset_index(drop=True)
        if d.empty:
            raise AssertionError(f"{model}: empty complete-case sample")
        # The source variables have already received their documented log/min-max
        # transformations.  A second, affine z-standardisation on the estimation
        # sample keeps those transformations intact while separating the local
        # intercept from the positive means of [0, 1]-scaled predictors.  This is
        # essential for an interpretable intercept-inclusive local condition-number
        # audit.  Slope surfaces for a given predictor change only by a positive
        # constant, so their spatial/temporal ordering is preserved.
        means = d[x_cols].mean(axis=0)
        sds = d[x_cols].std(axis=0, ddof=0)
        if (sds <= np.finfo(float).eps).any():
            bad = sds.index[sds <= np.finfo(float).eps].tolist()
            raise AssertionError(f"{model}: zero predictor standard deviation: {bad}")
        d.loc[:, x_cols] = (d[x_cols] - means) / sds
        if not np.isfinite(d[x_cols].to_numpy(float)).all():
            raise AssertionError(f"{model}: non-finite z-standardised predictor")
        d.attrs["predictor_zscore"] = {
            col: {"mean": float(means[col]), "sd_population": float(sds[col])}
            for col in x_cols
        }
        return d, y_col, x_cols

    def fit(
        self,
        d: pd.DataFrame,
        y_col: str,
        x_cols: list[str],
        bw_m: float,
        temporal_rate_m_per_year: float,
    ):
        tau = float(temporal_rate_m_per_year) ** 2
        return GTWR(
            d[["X_m", "Y_m"]].to_numpy(float),
            d[["Year"]].to_numpy(float),
            d[x_cols].to_numpy(float),
            d[[y_col]].to_numpy(float),
            bw=float(bw_m),
            tau=tau,
            kernel="gaussian",
            fixed=True,
            thread=self.threads,
        ).fit()

    def cal_aicc(
        self,
        d: pd.DataFrame,
        y_col: str,
        x_cols: list[str],
        bw_m: float,
        temporal_rate_m_per_year: float,
    ) -> float:
        """Calculate only the selection diagnostic, avoiding full-fit output."""
        model = GTWR(
            d[["X_m", "Y_m"]].to_numpy(float),
            d[["Year"]].to_numpy(float),
            d[x_cols].to_numpy(float),
            d[[y_col]].to_numpy(float),
            bw=float(bw_m),
            tau=float(temporal_rate_m_per_year) ** 2,
            kernel="gaussian",
            fixed=True,
            thread=self.threads,
        )
        return float(get_AICc(model.cal_aic()))

    def select_bandwidth(self) -> tuple[float, float]:
        d, y_col, x_cols = self.prep("A_main")
        trace_path = self.result_dir / "bandwidth_trace.json"
        if trace_path.exists():
            trace = json.loads(trace_path.read_text(encoding="utf-8"))
        else:
            trace = []
        tried = {
            (float(row["bw_km"]), float(row["temporal_bandwidth_years"])): row
            for row in trace
        }

        def evaluate(bw_km: float, temporal_bw_years: float) -> dict:
            key = (round(float(bw_km), 6), round(float(temporal_bw_years), 6))
            if key in tried:
                print(json.dumps({"cached": True, **tried[key]}), flush=True)
                return tried[key]
            started = time.time()
            rate_km = float(bw_km) / float(temporal_bw_years)
            aicc = self.cal_aicc(
                d, y_col, x_cols, bw_km * 1000.0, rate_km * 1000.0
            )
            row = {
                "bw_km": key[0],
                "temporal_bandwidth_years": key[1],
                "temporal_rate_km_per_year": rate_km,
                "tau_m2_per_year2": (rate_km * 1000.0) ** 2,
                "aicc": aicc,
                "valid": True,
                "elapsed_s": round(time.time() - started, 2),
            }
            if not np.isfinite(row["aicc"]):
                raise AssertionError(row)
            tried[key] = row
            atomic_json(sorted(tried.values(), key=lambda x: (x["bw_km"], x["temporal_bandwidth_years"])), trace_path)
            print(json.dumps(row), flush=True)
            return row

        for bw_km in COARSE_BW_KM:
            for temporal_bw_years in COARSE_TEMPORAL_BW_YEARS:
                evaluate(bw_km, temporal_bw_years)

        # Select the first-stage anchor only from the declared coarse grid;
        # cached refinement points from a resumed run must not redefine it.
        coarse_rows = [
            tried[(float(bw), float(temporal_bw))]
            for bw in COARSE_BW_KM
            for temporal_bw in COARSE_TEMPORAL_BW_YEARS
        ]
        coarse_valid = [row for row in coarse_rows if row.get("valid", True)]
        if not coarse_valid:
            raise RuntimeError("Every coarse bandwidth combination was numerically unstable")
        coarse_best = min(coarse_valid, key=lambda row: row["aicc"])
        bw0 = float(coarse_best["bw_km"])
        temporal0 = float(coarse_best["temporal_bandwidth_years"])
        refine_bws = sorted({
            round(v, 3)
            for v in (bw0 * 0.90, bw0, bw0 * 1.10)
            if 60.0 <= v <= 650.0
        })
        refine_temporal = sorted({
            round(temporal0 + delta, 3)
            for delta in (-0.50, -0.25, 0.0, 0.25, 0.50)
            if 0.75 <= temporal0 + delta <= 8.0
        })
        for bw_km in refine_bws:
            for temporal_bw in refine_temporal:
                evaluate(bw_km, temporal_bw)

        observed_best = min(
            (row for row in tried.values() if row.get("valid", True)),
            key=lambda row: row["aicc"],
        )
        centre_bw = float(observed_best["bw_km"])
        centre_temporal = float(observed_best["temporal_bandwidth_years"])
        final_bws = sorted({
            round(centre_bw * f, 3) for f in (0.90, 1.0, 1.10)
            if 55.0 <= centre_bw * f <= 700.0
        })
        final_temporal = sorted({
            round(centre_temporal + delta, 3) for delta in (-0.125, 0.0, 0.125)
            if 0.5 <= centre_temporal + delta <= 10.0
        })
        for bw_km in final_bws:
            for temporal_bw in final_temporal:
                evaluate(bw_km, temporal_bw)

        valid_rows = [row for row in tried.values() if row.get("valid", True)]
        best = min(valid_rows, key=lambda row: row["aicc"])
        # Fail visibly if the best point remains on the outer search boundary.
        if best["bw_km"] == max(r["bw_km"] for r in valid_rows):
            raise RuntimeError(f"Best spatial bandwidth lies on search boundary: {best}")
        if best["temporal_bandwidth_years"] in {
            min(r["temporal_bandwidth_years"] for r in valid_rows),
            max(r["temporal_bandwidth_years"] for r in valid_rows),
        }:
            raise RuntimeError(f"Best temporal rate lies on search boundary: {best}")

        selection = {
            "selection_model": "A_main",
            "criterion": "minimum AICc",
            "kernel": "Gaussian",
            "fixed_distance": True,
            "projection": PROJ4,
            "coordinate_unit": "metre",
            "time_unit": "year index (2009=1, ..., 2022=14)",
            "coarse_bw_km": list(COARSE_BW_KM),
            "coarse_temporal_bandwidth_years": list(COARSE_TEMPORAL_BW_YEARS),
            "refinement_rule": (
                "90/100/110% spatial and +/-0.50 year temporal grid around the "
                "coarse optimum, followed by a 3x3 local grid"
            ),
            "numerical_stability_rule": (
                "The grid starts at 75 km because 50 km candidates were separately "
                "diagnosed as ill-conditioned; the selected specification is then "
                "subjected to an explicit local-condition-number audit"
            ),
            "selected": best,
            "evaluated_combinations": int(len(tried)),
            "trace_file": str(trace_path),
        }
        atomic_json(selection, self.result_dir / "bandwidth_selection.json")
        print("SELECTED " + json.dumps(best), flush=True)
        return float(best["bw_km"]) * 1000.0, float(best["temporal_rate_km_per_year"]) * 1000.0

    def run_all(
        self, bw_m: float, rate_m: float, models: list[str] | None = None
    ) -> list[dict]:
        metas: list[dict] = []
        selected_models = list(MODELS) if models is None else list(models)
        unknown = sorted(set(selected_models) - set(MODELS))
        if unknown:
            raise ValueError(f"Unknown model names: {unknown}")
        if not selected_models:
            raise ValueError("At least one model must be requested")
        for model in selected_models:
            d, y_col, x_cols = self.prep(model)
            started = time.time()
            res = self.fit(d, y_col, x_cols, bw_m, rate_m)
            coef_names = ["intercept"] + x_cols
            assert res.betas.shape == (len(d), len(coef_names))
            assert res.tvalues.shape == (len(d), len(coef_names))
            assert np.isfinite(res.betas).all()
            assert np.isfinite(res.tvalues).all()

            out = d[[
                "Code", "Year", "ActualYear", "Lon", "Lai", "X_m", "Y_m", "CountyType"
            ]].copy()
            # Export slopes on the documented transformed/min-max predictor
            # scale so downstream EHSA is not made sensitive to rounding after
            # the additional numerical z-standardisation.  The model was fitted
            # with x_z=(x-mean)/sd, hence beta_x=beta_z/sd and
            # intercept_x=intercept_z-sum(beta_z*mean/sd).  Slope t statistics
            # are invariant to this positive affine rescaling.
            zstats = d.attrs["predictor_zscore"]
            means_array = np.asarray([zstats[col]["mean"] for col in x_cols])
            sds_array = np.asarray([zstats[col]["sd_population"] for col in x_cols])
            out["beta_intercept"] = (
                res.betas[:, 0]
                - np.sum(res.betas[:, 1:] * (means_array / sds_array), axis=1)
            )
            out["beta_intercept_z"] = res.betas[:, 0]
            out["t_intercept_z"] = res.tvalues[:, 0]
            for j, col in enumerate(x_cols, start=1):
                out[f"beta_{col}"] = res.betas[:, j] / sds_array[j - 1]
                out[f"beta_z_{col}"] = res.betas[:, j]
                out[f"t_{col}"] = res.tvalues[:, j]
            path = self.result_dir / f"local_{model}.csv"
            out.to_csv(path, index=False)
            check = pd.read_csv(path, dtype={"Code": str})
            assert len(check) == len(out)

            meta = {
                "model": model,
                "dv": y_col,
                "x_variables": x_cols,
                "n": int(res.n),
                "counties": int(d["Code"].nunique()),
                "year_min": int(d["ActualYear"].min()),
                "year_max": int(d["ActualYear"].max()),
                "bw_m": float(bw_m),
                "bw_km": float(bw_m / 1000.0),
                "temporal_rate_m_per_year": float(rate_m),
                "temporal_rate_km_per_year": float(rate_m / 1000.0),
                "tau_m2_per_year2": float(rate_m**2),
                "temporal_bandwidth_years": (
                    float(bw_m / rate_m) if rate_m > 0 else None
                ),
                "kernel": "Gaussian",
                "fixed_distance": True,
                "projection": PROJ4,
                "predictor_preprocessing": (
                    "documented log/min-max transformation followed by global "
                    "z-standardisation within the model complete-case sample"
                ),
                "predictor_zscore_parameters": d.attrs["predictor_zscore"],
                "coefficient_export_scale": (
                    "beta_<factor> and beta_intercept are back-transformed to "
                    "the documented transformed/min-max predictor scale; "
                    "beta_z_<factor> and beta_intercept_z retain the fitted "
                    "global-z scale; slope t statistics are scale-invariant"
                ),
                "R2": float(res.R2),
                "adj_R2": float(res.adj_R2),
                "aicc": float(res.aicc),
                "elapsed_s": round(time.time() - started, 2),
                "output": str(path),
                "output_sha256": sha256(path),
            }
            if model == "C_rei":
                meta["sample_restriction"] = "2009-2017; Xinjiang excluded"
            metas.append(meta)
            atomic_json(metas, self.result_dir / "model_meta.json")
            print(json.dumps(meta, ensure_ascii=False), flush=True)
        return metas


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "gtwr_results_metric")
    parser.add_argument("--threads", type=int, default=8)
    parser.add_argument("--select-only", action="store_true")
    parser.add_argument("--bw-km", type=float)
    parser.add_argument("--temporal-rate-km-per-year", type=float)
    parser.add_argument(
        "--models", nargs="+", choices=list(MODELS), default=list(MODELS),
        help="models to fit after bandwidth selection; use A_main for the final main run",
    )
    args = parser.parse_args()
    if (args.bw_km is None) != (args.temporal_rate_km_per_year is None):
        raise ValueError("Supply both --bw-km and --temporal-rate-km-per-year, or neither")
    args.output_dir.mkdir(parents=True, exist_ok=True)

    std = pd.read_csv(args.input, dtype={"Code": str})
    assert len(std) == 38_150 and std["Code"].nunique() == 2_725
    runner = MetricRunner(std, args.output_dir, args.threads)
    environment = {
        "timestamp_epoch": time.time(),
        "python": sys.version,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "pyproj": pyproj.__version__,
        "mgtwr": getattr(mgtwr, "__version__", "unknown"),
        "threads": args.threads,
        "input": str(args.input),
        "input_sha256": sha256(args.input),
        "projection": PROJ4,
        "legacy_outputs_modified": False,
        "local_county_type_dummies": False,
        "global_predictor_z_score_after_documented_transform": True,
        "reason_county_type_dummies_excluded": (
            "time-invariant locally sparse categories caused near-singular local design matrices"
        ),
    }
    atomic_json(environment, args.output_dir / "run_environment.json")

    if args.bw_km is None:
        bw_m, rate_m = runner.select_bandwidth()
    else:
        bw_m = float(args.bw_km) * 1000.0
        rate_m = float(args.temporal_rate_km_per_year) * 1000.0
    if not args.select_only:
        metas = runner.run_all(bw_m, rate_m, models=args.models)
        by_model = {row["model"]: row for row in metas}
        if "A_main" in by_model:
            assert by_model["A_main"]["n"] == 27_299
            assert by_model["A_main"]["year_max"] == 2022
        if "B_netpop" in by_model:
            assert by_model["B_netpop"]["year_max"] == 2021
        if "C_rei" in by_model:
            assert by_model["C_rei"]["year_max"] == 2017
        print("ALL METRIC GTWR MODELS PASS", flush=True)


if __name__ == "__main__":
    main()
