#!/usr/bin/env python3
"""Build an isolated GTWR coefficient table masked by the joint CN+VDP flag."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import pandas as pd


BETA_COLUMNS = [
    "beta_X1", "beta_X2", "beta_TRDEP", "beta_X7", "beta_RESH",
    "beta_X16", "beta_X9", "beta_X10", "beta_X11", "beta_X13",
    "beta_X14", "beta_X3", "beta_X4", "beta_X8", "beta_X6",
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--local", type=Path, required=True)
    parser.add_argument("--vdp", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    local = pd.read_csv(args.local, dtype={"Code": str})
    vdp = pd.read_csv(args.vdp, dtype={"Code": str})
    assert set(BETA_COLUMNS).issubset(local.columns)
    raw_flag = vdp["joint_cn_vdp_flag"]
    flag = raw_flag if raw_flag.dtype == bool else raw_flag.astype(str).str.lower().eq("true")
    flags = vdp.loc[flag, ["Code", "ActualYear"]]
    assert not flags.duplicated().any()
    keyed = local.merge(
        flags.assign(_mask=True), on=["Code", "ActualYear"], how="left", validate="one_to_one"
    )
    mask = keyed.pop("_mask").fillna(False).astype(bool)
    assert int(mask.sum()) == len(flags)
    before_nonnull = int(keyed.loc[mask, BETA_COLUMNS].notna().sum().sum())
    keyed.loc[mask, BETA_COLUMNS] = pd.NA
    assert int(keyed.loc[mask, BETA_COLUMNS].notna().sum().sum()) == 0
    args.output.parent.mkdir(parents=True, exist_ok=True)
    keyed.to_csv(args.output, index=False)
    check = pd.read_csv(args.output, dtype={"Code": str})
    assert len(check) == len(local)
    manifest = {
        "status": "passed",
        "rule": (
            "For Code-ActualYear rows with joint_cn_vdp_flag=True, set all 15 "
            "back-transformed beta_<factor> fields to NA; retain identifiers, "
            "coordinates, z-scale coefficients and t statistics"
        ),
        "flagged_rows": int(mask.sum()),
        "masked_beta_cells": before_nonnull,
        "local": {"path": str(args.local), "sha256": sha256(args.local)},
        "vdp": {"path": str(args.vdp), "sha256": sha256(args.vdp)},
        "output": {"path": str(args.output), "sha256": sha256(args.output)},
    }
    manifest_path = args.output.with_suffix(".manifest.json")
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
