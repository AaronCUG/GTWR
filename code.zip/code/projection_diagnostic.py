#!/usr/bin/env python3
"""Compare candidate China-wide projected CRSs against WGS84 geodesic distances."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from pyproj import CRS, Geod, Transformer


INPUT = Path(
    "/Users/lizhaojie/Desktop/working/land_redevelopment_rerun_20260725/"
    "data/full_experiment_panel_std_supplemented.csv"
)
OUT = Path("/Users/lizhaojie/Desktop/working/gtwr_metric_v15_20260726")

CANDIDATES = {
    "AEQD_China_105E_35N": "+proj=aeqd +lat_0=35 +lon_0=105 +datum=WGS84 +units=m +no_defs",
    "EQDC_China_25N_47N": "+proj=eqdc +lat_1=25 +lat_2=47 +lat_0=0 +lon_0=105 +datum=WGS84 +units=m +no_defs",
    "LCC_China_25N_47N": "+proj=lcc +lat_1=25 +lat_2=47 +lat_0=0 +lon_0=105 +datum=WGS84 +units=m +no_defs",
    "Albers_China_25N_47N": "+proj=aea +lat_1=25 +lat_2=47 +lat_0=0 +lon_0=105 +datum=WGS84 +units=m +no_defs",
}


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    d = pd.read_csv(INPUT, dtype={"Code": str}, usecols=["Code", "Lon", "Lai"])
    counties = d.drop_duplicates("Code").sort_values("Code").reset_index(drop=True)
    assert len(counties) == 2725
    lon = counties["Lon"].to_numpy(float)
    lat = counties["Lai"].to_numpy(float)

    rng = np.random.default_rng(20260726)
    pair_count = 300_000
    i = rng.integers(0, len(counties), pair_count)
    j = rng.integers(0, len(counties), pair_count)
    keep = i != j
    i, j = i[keep], j[keep]
    geod = Geod(ellps="WGS84")
    _, _, geodesic_m = geod.inv(lon[i], lat[i], lon[j], lat[j])
    positive = geodesic_m > 1.0
    i, j, geodesic_m = i[positive], j[positive], geodesic_m[positive]

    rows: list[dict] = []
    coordinates: dict[str, dict[str, list[float]]] = {}
    for name, definition in CANDIDATES.items():
        crs = CRS.from_proj4(definition)
        transformer = Transformer.from_crs("EPSG:4326", crs, always_xy=True)
        x, y = transformer.transform(lon, lat)
        x = np.asarray(x, dtype=float)
        y = np.asarray(y, dtype=float)
        euclidean_m = np.hypot(x[i] - x[j], y[i] - y[j])
        relative = euclidean_m / geodesic_m - 1.0
        abs_relative = np.abs(relative)
        rows.append(
            {
                "projection": name,
                "proj4": crs.to_proj4(),
                "pairs": int(len(relative)),
                "mean_signed_relative_error": float(relative.mean()),
                "mean_absolute_relative_error": float(abs_relative.mean()),
                "median_absolute_relative_error": float(np.median(abs_relative)),
                "p95_absolute_relative_error": float(np.quantile(abs_relative, 0.95)),
                "max_absolute_relative_error": float(abs_relative.max()),
                "rmse_relative_error": float(np.sqrt(np.mean(relative**2))),
            }
        )
        coordinates[name] = {"x_m": x.tolist(), "y_m": y.tolist()}

    result = pd.DataFrame(rows).sort_values(
        ["rmse_relative_error", "mean_absolute_relative_error"]
    )
    result.to_csv(OUT / "projection_distance_diagnostic.csv", index=False)
    best = result.iloc[0].to_dict()
    payload = {
        "input": str(INPUT),
        "county_count": int(len(counties)),
        "sampled_pair_count": int(len(i)),
        "sampling_seed": 20260726,
        "selection_rule": "minimum RMSE of relative planar-distance error against WGS84 geodesic distance",
        "selected": best,
    }
    (OUT / "projection_selection.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(result.to_string(index=False))
    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
