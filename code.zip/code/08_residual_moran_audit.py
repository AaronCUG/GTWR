#!/usr/bin/env python3
"""Annual Moran's I audit for residuals of the final metric A_main GTWR.

Predictions are reconstructed from the exported z-scale coefficients and the
z-score parameters in model_meta.json.  Moran's I uses symmetric binary
distance-band weights in the same AEQD metric coordinate system as GTWR.
Permutation p-values test positive spatial autocorrelation.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.spatial import cKDTree


ROOT = Path("/Users/lizhaojie/Desktop/working/gtwr_metric_v15_20260726")
LOCAL = ROOT / "gtwr_results_metric_final/local_A_main.csv"
META = ROOT / "gtwr_results_metric_final/model_meta.json"
PANEL = Path(
    "/Users/lizhaojie/Desktop/working/land_redevelopment_rerun_20260725/"
    "data/full_experiment_panel_std_supplemented.csv"
)
OUTDIR = ROOT / "residual_moran_audit"
DISTANCES_KM = (50, 100, 200)
PERMUTATIONS = 499
SEED = 20260726


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def moran_binary(z: np.ndarray, pairs: np.ndarray) -> float:
    z = z - z.mean()
    if len(pairs) == 0 or np.dot(z, z) == 0:
        return np.nan
    # Symmetric binary W: numerator and S0 both have a factor of two.
    return float(len(z) * np.sum(z[pairs[:, 0]] * z[pairs[:, 1]]) / (len(pairs) * np.dot(z, z)))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--local", type=Path, default=LOCAL)
    parser.add_argument("--meta", type=Path, default=META)
    parser.add_argument("--panel", type=Path, default=PANEL)
    parser.add_argument("--output-dir", type=Path, default=OUTDIR)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    local = pd.read_csv(args.local, dtype={"Code": str})
    panel = pd.read_csv(args.panel, dtype={"Code": str})
    meta = json.loads(args.meta.read_text(encoding="utf-8"))[0]
    xcols = list(meta["x_variables"])
    zparams = meta["predictor_zscore_parameters"]
    needed = ["Code", "Year", "ActualYear", "URP_clean", *xcols]
    sample = panel[needed].replace([np.inf, -np.inf], np.nan).dropna()
    merged = local.merge(
        sample,
        on=["Code", "Year", "ActualYear"],
        how="left",
        validate="one_to_one",
    )
    assert len(merged) == 27_299
    assert merged["URP_clean"].notna().all()
    fitted = merged["beta_intercept_z"].to_numpy(float).copy()
    for col in xcols:
        xz = (merged[col].to_numpy(float) - zparams[col]["mean"]) / zparams[col]["sd_population"]
        fitted += merged[f"beta_z_{col}"].to_numpy(float) * xz
    merged["fitted"] = fitted
    merged["residual"] = merged["URP_clean"].to_numpy(float) - fitted
    y = merged["URP_clean"].to_numpy(float)
    r2_reconstructed = 1 - np.sum(merged["residual"].to_numpy() ** 2) / np.sum((y - y.mean()) ** 2)
    assert abs(r2_reconstructed - meta["R2"]) < 1e-10, (r2_reconstructed, meta["R2"])

    rng = np.random.default_rng(SEED)
    rows: list[dict] = []
    for year, d in merged.groupby("ActualYear", sort=True):
        d = d.reset_index(drop=True)
        coords = d[["X_m", "Y_m"]].to_numpy(float)
        residual = d["residual"].to_numpy(float)
        tree = cKDTree(coords)
        for distance_km in DISTANCES_KM:
            pairs = tree.query_pairs(distance_km * 1000.0, output_type="ndarray")
            degree = np.bincount(pairs.ravel(), minlength=len(d)) if len(pairs) else np.zeros(len(d), int)
            observed = moran_binary(residual, pairs)
            permuted = np.empty(PERMUTATIONS, dtype=float)
            for k in range(PERMUTATIONS):
                permuted[k] = moran_binary(rng.permutation(residual), pairs)
            p_greater = (1 + int(np.sum(permuted >= observed))) / (PERMUTATIONS + 1)
            rows.append(
                {
                    "ActualYear": int(year),
                    "DistanceKm": int(distance_km),
                    "N": int(len(d)),
                    "UndirectedEdges": int(len(pairs)),
                    "Isolates": int(np.sum(degree == 0)),
                    "MoranI": observed,
                    "ExpectedI": -1.0 / (len(d) - 1),
                    "PermutationP_Positive": p_greater,
                    "Permutations": PERMUTATIONS,
                }
            )
    table = pd.DataFrame(rows)
    output = args.output_dir / "annual_residual_moran_binary_distance.csv"
    table.to_csv(output, index=False)
    summary = (
        table.groupby("DistanceKm")
        .agg(
            YearCount=("ActualYear", "count"),
            MoranMin=("MoranI", "min"),
            MoranMedian=("MoranI", "median"),
            MoranMax=("MoranI", "max"),
            YearsP_lt_0p05=("PermutationP_Positive", lambda x: int(np.sum(x < 0.05))),
            MaxIsolates=("Isolates", "max"),
        )
        .reset_index()
    )
    summary_path = args.output_dir / "annual_residual_moran_summary.csv"
    summary.to_csv(summary_path, index=False)
    manifest = {
        "status": "passed",
        "model_output": str(args.local),
        "model_output_sha256": sha256(args.local),
        "panel": str(args.panel),
        "panel_sha256": sha256(args.panel),
        "prediction_reconstruction_R2": float(r2_reconstructed),
        "weight_definition": (
            "symmetric binary distance-band weights in the final AEQD metric "
            "coordinates; Moran numerator/S0 use both directions"
        ),
        "distances_km": list(DISTANCES_KM),
        "permutations": PERMUTATIONS,
        "seed": SEED,
        "alternative": "positive residual spatial autocorrelation",
        "output": str(output),
        "output_sha256": sha256(output),
        "summary": str(summary_path),
        "summary_sha256": sha256(summary_path),
    }
    manifest_path = args.output_dir / "residual_moran_manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(summary.to_string(index=False))
    print(table.to_string(index=False))
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
