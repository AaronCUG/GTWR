#!/usr/bin/env python3
"""Reproducible local-stability audit for candidate metric GTWR bandwidths.

This diagnostic is deliberately separate from the estimation script.  It
evaluates all complete-case A-main target rows, not a convenience sample, and
reports three quantities that AICc alone does not constrain:

* Kish effective sample size of the Gaussian local weights;
* a scale-free local condition number after weighted centering/scaling; and
* the largest diagonal of the inverse local weighted correlation matrix
  (maximum local VIF).

The predeclared alert thresholds are k=16 for the effective sample size (15
slopes plus intercept), 30 for the scale-free condition number, and 10 for the
maximum local VIF.  The latter two are diagnostics, not automatic proof that a
coefficient is invalid; the output preserves the full distributions so the
decision rule cannot be chosen after seeing only a favourable summary.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from pyproj import CRS, Transformer
from scipy.spatial import cKDTree


ROOT = Path("/Users/lizhaojie/Desktop/working/gtwr_metric_v15_20260726")
INPUT = ROOT / "data/full_experiment_panel_std_supplemented.csv"
PROJ4 = "+proj=aeqd +lat_0=35 +lon_0=105 +datum=WGS84 +units=m +no_defs"
X15 = [
    "X1", "X2", "TRDEP", "X7", "RESH", "X16", "X9", "X10", "X11",
    "X13", "X14", "X3", "X4", "X8", "X6",
]
K_PARAMETERS = len(X15) + 1
CN_ALERT = 30.0
VIF_ALERT = 10.0
WEIGHT_RADIUS_BW = 6.0


def parse_pair(text: str) -> tuple[float, float]:
    try:
        spatial, temporal = (float(value) for value in text.split(",", 1))
    except Exception as exc:
        raise argparse.ArgumentTypeError("pair must be spatial_km,temporal_years") from exc
    if spatial <= 0 or temporal <= 0:
        raise argparse.ArgumentTypeError("bandwidths must be positive")
    return spatial, temporal


def finite_quantile(values: np.ndarray, q: float) -> float:
    finite = values[np.isfinite(values)]
    return float(np.quantile(finite, q)) if len(finite) else float("nan")


def load_design(input_path: Path) -> tuple[pd.DataFrame, np.ndarray, np.ndarray]:
    raw = pd.read_csv(input_path, dtype={"Code": str})
    cols = ["Code", "Year", "ActualYear", "Lon", "Lai", "CountyType", "URP_clean"] + X15
    data = raw[cols].replace([np.inf, -np.inf], np.nan).dropna().reset_index(drop=True)
    if len(data) != 27_299:
        raise AssertionError(f"unexpected complete-case count: {len(data)}")
    transformer = Transformer.from_crs(
        "EPSG:4326", CRS.from_proj4(PROJ4), always_xy=True
    )
    x_m, y_m = transformer.transform(
        data["Lon"].to_numpy(float), data["Lai"].to_numpy(float)
    )
    spatial = np.column_stack([x_m, y_m])
    design = data[X15].to_numpy(float)
    if not np.isfinite(spatial).all() or not np.isfinite(design).all():
        raise AssertionError("non-finite projected coordinate or design value")
    return data, spatial, design


def audit_pair(
    data: pd.DataFrame,
    spatial: np.ndarray,
    design: np.ndarray,
    spatial_bw_km: float,
    temporal_bw_years: float,
) -> pd.DataFrame:
    bw_m = spatial_bw_km * 1000.0
    temporal_rate_m_per_year = bw_m / temporal_bw_years
    points = np.column_stack([
        spatial,
        data["Year"].to_numpy(float) * temporal_rate_m_per_year,
    ])
    tree = cKDTree(points)
    rows: list[dict] = []
    for i in range(len(data)):
        idx = np.asarray(
            tree.query_ball_point(points[i], r=WEIGHT_RADIUS_BW * bw_m), dtype=int
        )
        distance = np.linalg.norm(points[idx] - points[i], axis=1)
        weights = np.exp(-0.5 * np.square(distance / bw_m))
        weight_sum = float(weights.sum())
        effective_n = float(weight_sum**2 / np.square(weights).sum())

        local = design[idx]
        mean = np.sum(local * weights[:, None], axis=0) / weight_sum
        centered = local - mean
        variance = np.sum(np.square(centered) * weights[:, None], axis=0) / weight_sum
        if np.any(variance <= np.finfo(float).eps):
            condition = float("inf")
            max_vif = float("inf")
            min_local_sd = float(np.sqrt(max(float(variance.min()), 0.0)))
        else:
            standardized = centered / np.sqrt(variance)
            corr = (standardized * weights[:, None]).T @ standardized / weight_sum
            corr = (corr + corr.T) / 2.0
            eigenvalues = np.linalg.eigvalsh(corr)
            if eigenvalues[0] <= 0:
                condition = float("inf")
            else:
                condition = float(np.sqrt(eigenvalues[-1] / eigenvalues[0]))
            try:
                max_vif = float(np.diag(np.linalg.inv(corr)).max())
            except np.linalg.LinAlgError:
                max_vif = float("inf")
            min_local_sd = float(np.sqrt(variance.min()))

        rows.append({
            "spatial_bw_km": spatial_bw_km,
            "temporal_bw_years": temporal_bw_years,
            "temporal_rate_km_per_year": spatial_bw_km / temporal_bw_years,
            "target_row": i,
            "Code": data.at[i, "Code"],
            "ActualYear": int(data.at[i, "ActualYear"]),
            "CountyType": data.at[i, "CountyType"],
            "Xinjiang": bool(data.at[i, "Code"].startswith("65")),
            "neighbors_within_6bw": int(len(idx)),
            "effective_n": effective_n,
            "scale_free_local_cn": condition,
            "max_local_vif": max_vif,
            "min_local_predictor_sd": min_local_sd,
        })
    return pd.DataFrame(rows)


def summarize(frame: pd.DataFrame) -> dict:
    neff = frame["effective_n"].to_numpy(float)
    cn = frame["scale_free_local_cn"].to_numpy(float)
    vif = frame["max_local_vif"].to_numpy(float)
    return {
        "spatial_bw_km": float(frame["spatial_bw_km"].iloc[0]),
        "temporal_bw_years": float(frame["temporal_bw_years"].iloc[0]),
        "temporal_rate_km_per_year": float(frame["temporal_rate_km_per_year"].iloc[0]),
        "n_targets": int(len(frame)),
        "effective_n_min": float(np.min(neff)),
        "effective_n_p01": float(np.quantile(neff, 0.01)),
        "effective_n_p05": float(np.quantile(neff, 0.05)),
        "effective_n_median": float(np.median(neff)),
        "pct_effective_n_lt_k": float(np.mean(neff < K_PARAMETERS) * 100.0),
        "pct_effective_n_lt_2k": float(np.mean(neff < 2 * K_PARAMETERS) * 100.0),
        "local_cn_median": finite_quantile(cn, 0.50),
        "local_cn_p95": finite_quantile(cn, 0.95),
        "local_cn_p99": finite_quantile(cn, 0.99),
        "local_cn_max": finite_quantile(cn, 1.00),
        "pct_local_cn_gt_30": float(np.mean(cn > CN_ALERT) * 100.0),
        "pct_local_cn_infinite": float(np.mean(~np.isfinite(cn)) * 100.0),
        "max_local_vif_median": finite_quantile(vif, 0.50),
        "max_local_vif_p95": finite_quantile(vif, 0.95),
        "max_local_vif_p99": finite_quantile(vif, 0.99),
        "max_local_vif_max": finite_quantile(vif, 1.00),
        "pct_max_local_vif_gt_10": float(np.mean(vif > VIF_ALERT) * 100.0),
        "pct_max_local_vif_infinite": float(np.mean(~np.isfinite(vif)) * 100.0),
        "hard_neff_gate_all_ge_k": bool(np.all(neff >= K_PARAMETERS)),
        "diagnostic_cn_gate_p95_le_30": bool(finite_quantile(cn, 0.95) <= CN_ALERT),
        "diagnostic_vif_gate_p95_le_10": bool(finite_quantile(vif, 0.95) <= VIF_ALERT),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=INPUT)
    parser.add_argument(
        "--pair", action="append", type=parse_pair, required=True,
        help="candidate spatial_km,temporal_years; repeat for multiple candidates",
    )
    parser.add_argument(
        "--output-dir", type=Path, default=ROOT / "bandwidth_stability_grid"
    )
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    data, spatial, design = load_design(args.input)
    all_details: list[pd.DataFrame] = []
    summaries: list[dict] = []
    for spatial_bw_km, temporal_bw_years in args.pair:
        detail = audit_pair(
            data, spatial, design, spatial_bw_km, temporal_bw_years
        )
        all_details.append(detail)
        row = summarize(detail)
        summaries.append(row)
        print(json.dumps(row, ensure_ascii=False), flush=True)

    details = pd.concat(all_details, ignore_index=True)
    summary = pd.DataFrame(summaries).sort_values(
        ["spatial_bw_km", "temporal_bw_years"]
    )
    details_path = args.output_dir / "local_stability_all_targets.csv"
    summary_path = args.output_dir / "bandwidth_stability_summary.csv"
    details.to_csv(details_path, index=False)
    summary.to_csv(summary_path, index=False)
    manifest = {
        "input": str(args.input),
        "projection": PROJ4,
        "kernel": "fixed Gaussian",
        "weight_radius_for_diagnostic_only": "6 bandwidths; GTWR fit uses all weights",
        "predictors": X15,
        "k_parameters_including_intercept": K_PARAMETERS,
        "predeclared_alerts": {
            "hard_minimum_effective_n": K_PARAMETERS,
            "preferred_effective_n": 2 * K_PARAMETERS,
            "scale_free_local_condition_number": CN_ALERT,
            "maximum_local_vif": VIF_ALERT,
        },
        "candidate_pairs": [
            {"spatial_bw_km": s, "temporal_bw_years": t} for s, t in args.pair
        ],
        "targets": "all 27,299 A-main complete-case county-year rows",
        "summary_csv": str(summary_path),
        "detail_csv": str(details_path),
    }
    (args.output_dir / "stability_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"PASS: {summary_path}", flush=True)


if __name__ == "__main__":
    main()
