#!/usr/bin/env python3
"""Audit local design-matrix conditioning for the metric GTWR specification.

The diagnostic reproduces the Gaussian space-time weights used by ``mgtwr``.
It evaluates every 17th complete-case target (a deterministic sample spanning
the ordered panel) plus each target whose code begins with 65 (Xinjiang), where
the legacy locally varying county-type indicators were most unstable.  Weights
beyond six bandwidths are below exp(-18) and are omitted only for this
conditioning diagnostic, not for model estimation.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from pyproj import CRS, Transformer
from scipy.spatial import cKDTree

ROOT = Path("/Users/lizhaojie/Desktop/working/gtwr_metric_v15_20260726")
INPUT = ROOT / "data/full_experiment_panel_std_supplemented.csv"
PROJ4 = "+proj=aeqd +lat_0=35 +lon_0=105 +datum=WGS84 +units=m +no_defs"
X15 = [
    "X1", "X2", "TRDEP", "X7", "RESH", "X16", "X9", "X10", "X11",
    "X13", "X14", "X3", "X4", "X8", "X6",
]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--bw-km", type=float, required=True)
    ap.add_argument("--temporal-rate-km-per-year", type=float, required=True)
    ap.add_argument("--output", type=Path, default=ROOT / "local_condition_diagnostic.csv")
    args = ap.parse_args()

    raw = pd.read_csv(INPUT, dtype={"Code": str})
    cols = ["Code", "Year", "ActualYear", "Lon", "Lai", "CountyType", "URP_clean"] + X15 + ["D_SXQ", "D_XJS"]
    d = raw[cols].replace([np.inf, -np.inf], np.nan).dropna().reset_index(drop=True)
    assert len(d) == 27_299
    transformer = Transformer.from_crs("EPSG:4326", CRS.from_proj4(PROJ4), always_xy=True)
    xm, ym = transformer.transform(d["Lon"].to_numpy(float), d["Lai"].to_numpy(float))
    rate_m = args.temporal_rate_km_per_year * 1000.0
    pts = np.column_stack([xm, ym, d["Year"].to_numpy(float) * rate_m])
    bw_m = args.bw_km * 1000.0
    tree = cKDTree(pts)

    deterministic = np.arange(0, len(d), 17, dtype=int)
    xinjiang = np.flatnonzero(d["Code"].str.startswith("65").to_numpy())
    targets = np.unique(np.concatenate([deterministic, xinjiang]))
    designs = {
        "15_continuous": np.column_stack([np.ones(len(d)), d[X15].to_numpy(float)]),
        "15_plus_2_local_type_dummies": np.column_stack([
            np.ones(len(d)), d[X15 + ["D_SXQ", "D_XJS"]].to_numpy(float)
        ]),
    }

    rows: list[dict] = []
    for pos, i in enumerate(targets):
        idx = np.asarray(tree.query_ball_point(pts[i], r=6.0 * bw_m), dtype=int)
        dist = np.linalg.norm(pts[idx] - pts[i], axis=1)
        w = np.exp(-0.5 * (dist / bw_m) ** 2)
        neff = float(w.sum() ** 2 / np.square(w).sum())
        for spec, X in designs.items():
            Xw = X[idx] * np.sqrt(w)[:, None]
            # Squared singular-value condition equals cond(X'WX) but avoids
            # explicitly forming a matrix with a less favourable scale.
            s = np.linalg.svd(Xw, compute_uv=False)
            cond = float((s[0] / s[-1]) ** 2) if s[-1] > 0 else float("inf")
            rows.append({
                "target_row": int(i),
                "Code": d.at[i, "Code"],
                "ActualYear": int(d.at[i, "ActualYear"]),
                "CountyType": d.at[i, "CountyType"],
                "Xinjiang": bool(d.at[i, "Code"].startswith("65")),
                "specification": spec,
                "neighbors_within_6bw": int(len(idx)),
                "effective_n": neff,
                "condition_XtWX": cond,
            })
        if pos % 250 == 0:
            print(f"{pos}/{len(targets)}", flush=True)

    out = pd.DataFrame(rows)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(args.output, index=False)
    summary = []
    for spec, g in out.groupby("specification"):
        for scope, q in (("all_audited_targets", g), ("Xinjiang", g[g["Xinjiang"]])):
            summary.append({
                "specification": spec,
                "scope": scope,
                "n_targets": int(len(q)),
                "condition_median": float(q["condition_XtWX"].median()),
                "condition_p95": float(q["condition_XtWX"].quantile(.95)),
                "condition_max": float(q["condition_XtWX"].max()),
                "pct_condition_gt_1e12": float(q["condition_XtWX"].gt(1e12).mean() * 100),
                "effective_n_min": float(q["effective_n"].min()),
            })
    payload = {
        "bw_km": args.bw_km,
        "temporal_rate_km_per_year": args.temporal_rate_km_per_year,
        "projection": PROJ4,
        "target_sampling": "every 17th complete-case row plus every Xinjiang row",
        "weight_cutoff_for_diagnostic_only": "6 bandwidths; model fits use all Gaussian weights",
        "summary": summary,
    }
    args.output.with_suffix(".json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
