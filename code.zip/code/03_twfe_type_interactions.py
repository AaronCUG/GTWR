#!/usr/bin/env python3
"""County- and year-FE robustness model with county-type slope interactions.

Time-invariant county-type main effects are absorbed by county fixed effects.
The model estimates the fifteen continuous candidate factors jointly and
interacts each with municipal-district and county-level-city indicators.  This
replaces the numerically unidentified practice of assigning those indicators
locally varying GTWR coefficients.
"""

from __future__ import annotations

import hashlib
import json
from math import erfc, sqrt
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path("/Users/lizhaojie/Desktop/working/gtwr_metric_v15_20260726")
INPUT = ROOT / "data/full_experiment_panel_std_supplemented.csv"
OUT = ROOT / "type_interaction_twfe"
FACTORS = {
    "LF": "X1", "FE": "X2", "TRD": "TRDEP", "BFL": "X7", "RES": "RESH",
    "PEY": "X16", "CGT": "X9", "PGDP": "X10", "IEC": "X11", "SIP": "X13",
    "TIP": "X14", "ETD": "X3", "AAP": "X4", "BAL": "X8", "FAI": "X6",
}


def residualize(values: np.ndarray, groups: list[np.ndarray], max_iter: int = 300, tol: float = 1e-11) -> np.ndarray:
    arr = np.asarray(values, dtype=float).copy()
    if arr.ndim == 1:
        arr = arr[:, None]
    for _ in range(max_iter):
        before = arr.copy()
        for group in groups:
            labels, inv = np.unique(group, return_inverse=True)
            sums = np.zeros((len(labels), arr.shape[1]))
            np.add.at(sums, inv, arr)
            arr -= (sums / np.bincount(inv)[:, None])[inv]
        if np.max(np.abs(arr - before)) < tol:
            return arr
    raise RuntimeError("Fixed-effect residualization did not converge")


def pvalue(z: float) -> float:
    return erfc(abs(float(z)) / sqrt(2.0)) if np.isfinite(z) else np.nan


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main() -> None:
    raw = pd.read_csv(INPUT, dtype={"Code": str})
    base_vars = list(FACTORS.values())
    cols = ["Code", "ActualYear", "CountyType", "URP_clean", "D_SXQ", "D_XJS"] + base_vars
    d = raw[cols].replace([np.inf, -np.inf], np.nan).dropna().copy()
    assert len(d) == 27_299 and d["Code"].nunique() == 2_120

    names = list(base_vars)
    arrays = [d[base_vars].to_numpy(float)]
    for dummy in ("D_SXQ", "D_XJS"):
        arrays.append(d[base_vars].to_numpy(float) * d[[dummy]].to_numpy(float))
        names.extend([f"{var}:{dummy}" for var in base_vars])
    X0 = np.column_stack(arrays)
    groups = [d["Code"].to_numpy(str), d["ActualYear"].to_numpy(str)]
    X = residualize(X0, groups)
    y = residualize(d["URP_clean"].to_numpy(float), groups).ravel()
    keep = np.std(X, axis=0) > 1e-12
    if not keep.all():
        raise AssertionError(f"Unexpected absorbed columns: {[n for n,k in zip(names,keep) if not k]}")

    xtx_inv = np.linalg.pinv(X.T @ X)
    beta = xtx_inv @ X.T @ y
    resid = y - X @ beta
    clusters = d["Code"].to_numpy(str)
    unique = np.unique(clusters)
    meat = np.zeros((len(names), len(names)))
    for county in unique:
        score = X[clusters == county].T @ resid[clusters == county]
        meat += np.outer(score, score)
    n, k = X.shape
    scale = (len(unique) / (len(unique) - 1)) * ((n - 1) / (n - k))
    cov = scale * xtx_inv @ meat @ xtx_inv

    name_to_i = {name: i for i, name in enumerate(names)}
    rows: list[dict] = []
    for label, var in FACTORS.items():
        ib = name_to_i[var]
        ids = name_to_i[f"{var}:D_SXQ"]
        idc = name_to_i[f"{var}:D_XJS"]
        for county_type, vector, difference_i in (
            ("County (reference)", {ib: 1.0}, None),
            ("Municipal district", {ib: 1.0, ids: 1.0}, ids),
            ("County-level city", {ib: 1.0, idc: 1.0}, idc),
        ):
            c = np.zeros(k)
            for i, value in vector.items():
                c[i] = value
            estimate = float(c @ beta)
            se = float(np.sqrt(max(c @ cov @ c, 0.0)))
            if difference_i is None:
                diff = diff_se = diff_p = np.nan
            else:
                diff = float(beta[difference_i])
                diff_se = float(np.sqrt(max(cov[difference_i, difference_i], 0.0)))
                diff_p = pvalue(diff / diff_se)
            rows.append({
                "Factor": label,
                "Variable": var,
                "CountyType": county_type,
                "Slope": estimate,
                "SE": se,
                "p_slope": pvalue(estimate / se),
                "Difference_from_county": diff,
                "SE_difference": diff_se,
                "p_difference": diff_p,
                "N": n,
                "Counties": len(unique),
            })
    result = pd.DataFrame(rows)
    OUT.mkdir(parents=True, exist_ok=True)
    result.to_csv(OUT / "twfe_county_type_interactions.csv", index=False)
    within_r2 = float(1 - resid @ resid / ((y - y.mean()) @ (y - y.mean())))
    meta = {
        "input": str(INPUT),
        "input_sha256": sha256(INPUT),
        "dependent_variable": "LRP",
        "specification": (
            "county and year fixed effects; all 15 standardized continuous factors "
            "entered jointly; each factor interacted with municipal-district and "
            "county-level-city indicators; county-clustered standard errors"
        ),
        "reference_type": "ordinary county",
        "N": n,
        "counties": int(len(unique)),
        "within_R2": within_r2,
        "rank": int(np.linalg.matrix_rank(X)),
        "columns": k,
        "condition_XtX": float(np.linalg.cond(X.T @ X)),
    }
    (OUT / "twfe_county_type_interactions_meta.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    if meta["rank"] != k or not np.isfinite(result[["Slope", "SE", "p_slope"]].to_numpy()).all():
        raise AssertionError(meta)
    print(json.dumps(meta, ensure_ascii=False, indent=2))
    print("PASS")


if __name__ == "__main__":
    main()
