#!/usr/bin/env python3
"""All-target PySAL-style local condition-number audit for metric GTWR.

The condition-number calculation follows ``mgwr.gwr.GWRResults``
``local_collinearity``: multiply the intercept-inclusive design by the local
kernel weights, normalize every resulting column by its Euclidean norm, and
take the ratio of the largest to the smallest singular value.  This is kept
separate from the locally centered correlation/VIF diagnostic because the two
quantities answer related but non-identical questions.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from pyproj import CRS, Transformer
from scipy.spatial import cKDTree


ROOT = Path("/Users/lizhaojie/Desktop/working/gtwr_metric_v15_20260726")
INPUT = ROOT / "data/full_experiment_panel_std_supplemented.csv"
PROJ4 = "+proj=aeqd +lat_0=35 +lon_0=105 +datum=WGS84 +units=m +no_defs"
X15 = [
    "X1", "X2", "TRDEP", "X7", "RESH", "X16", "X9", "X10", "X11",
    "X13", "X14", "X3", "X4", "X8", "X6",
]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=INPUT)
    parser.add_argument("--bw-km", type=float, required=True)
    parser.add_argument("--temporal-years", type=float, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--z-score", action="store_true",
        help=(
            "Globally centre and scale the already transformed predictors "
            "before forming the intercept-inclusive local design."
        ),
    )
    args = parser.parse_args()
    if args.bw_km <= 0 or args.temporal_years <= 0:
        raise ValueError("bandwidths must be positive")

    raw = pd.read_csv(args.input, dtype={"Code": str})
    cols = ["Code", "Year", "ActualYear", "Lon", "Lai", "URP_clean"] + X15
    d = raw[cols].replace([np.inf, -np.inf], np.nan).dropna().reset_index(drop=True)
    assert len(d) == 27_299 and d["Code"].nunique() == 2_120
    transformer = Transformer.from_crs(
        "EPSG:4326", CRS.from_proj4(PROJ4), always_xy=True
    )
    x_m, y_m = transformer.transform(d["Lon"].to_numpy(), d["Lai"].to_numpy())
    rate_m = args.bw_km * 1000.0 / args.temporal_years
    points = np.column_stack([
        x_m, y_m, d["Year"].to_numpy(float) * rate_m,
    ])
    bw_m = args.bw_km * 1000.0
    tree = cKDTree(points)
    predictor_values = d[X15].to_numpy(float)
    if args.z_score:
        predictor_means = predictor_values.mean(axis=0)
        predictor_sds = predictor_values.std(axis=0, ddof=0)
        if np.any(predictor_sds <= np.finfo(float).eps):
            raise AssertionError("zero global predictor standard deviation")
        predictor_values = (predictor_values - predictor_means) / predictor_sds
    design = np.column_stack([np.ones(len(d)), predictor_values])

    rows: list[dict] = []
    for i in range(len(d)):
        idx = np.asarray(tree.query_ball_point(points[i], 6.0 * bw_m), dtype=int)
        distance = np.linalg.norm(points[idx] - points[i], axis=1)
        weights = np.exp(-0.5 * np.square(distance / bw_m))
        xw = design[idx] * weights[:, None]
        norms = np.sqrt(np.square(xw).sum(axis=0))
        if np.any(norms <= np.finfo(float).eps):
            condition = float("inf")
        else:
            singular = np.linalg.svd(xw / norms, compute_uv=False)
            condition = (
                float(singular[0] / singular[-1])
                if singular[-1] > np.finfo(float).eps else float("inf")
            )
        effective_n = float(np.square(weights.sum()) / np.square(weights).sum())
        rows.append({
            "target_row": i,
            "Code": d.at[i, "Code"],
            "ActualYear": int(d.at[i, "ActualYear"]),
            "effective_n": effective_n,
            "pysal_style_local_condition_number": condition,
        })
        if i and i % 5000 == 0:
            print(f"{i}/{len(d)}", flush=True)

    frame = pd.DataFrame(rows)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    detail_path = args.output_dir / "pysal_style_local_cn_all_targets.csv"
    frame.to_csv(detail_path, index=False)
    cn = frame["pysal_style_local_condition_number"].to_numpy(float)
    neff = frame["effective_n"].to_numpy(float)
    summary = {
        "bw_km": args.bw_km,
        "temporal_bandwidth_years": args.temporal_years,
        "temporal_rate_km_per_year": args.bw_km / args.temporal_years,
        "n_targets": len(frame),
        "parameters_including_intercept": design.shape[1],
        "global_predictor_z_score": bool(args.z_score),
        "effective_n_min": float(neff.min()),
        "effective_n_p01": float(np.quantile(neff, .01)),
        "condition_median": float(np.median(cn)),
        "condition_p95": float(np.quantile(cn, .95)),
        "condition_p99": float(np.quantile(cn, .99)),
        "condition_max": float(np.max(cn)),
        "pct_condition_gt_30": float(np.mean(cn > 30) * 100),
        "definition": (
            "PySAL mgwr local_collinearity convention: X including intercept is "
            "multiplied by kernel w, each column is divided by its Euclidean "
            "norm, and condition number is largest/smallest singular value"
        ),
        "diagnostic_cutoff_only": "weights beyond six bandwidths omitted (<exp(-18))",
        "detail_csv": str(detail_path),
        "input": str(args.input),
    }
    (args.output_dir / "pysal_style_local_cn_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
