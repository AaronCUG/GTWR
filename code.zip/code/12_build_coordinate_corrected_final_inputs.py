#!/usr/bin/env python3
"""Build isolated final panel copies with seven fixed, audited coordinates.

Five clearly erroneous co-located codes receive representative points derived
from the AMap/GCJ-02 county polygons and iteratively inverted to WGS84.
Huangdao and Jiaonan receive distinct fixed multi-year land-record centres,
using pooled 2006--2012 medians to avoid endogenous year-to-year movement.
No analytical value other than Lon/Lai is changed.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path("/Users/lizhaojie/Desktop/working/gtwr_metric_v15_20260726")
FINAL = ROOT / "coordinate_corrected_final"
COORDINATE_AUDIT = FINAL / "coordinate_source_audit" / "fixed_representative_points_7codes.csv"
BASE = Path("/Users/lizhaojie/Desktop/working/land_redevelopment_rerun_20260725/data")
INPUTS = {
    "standardized": BASE / "full_experiment_panel_std_supplemented.csv",
    "unstandardized": BASE / "full_experiment_panel_supplemented.csv",
}

METHODS = {
    code: (
        "AMap county polygon internal representative point in GCJ-02, "
        "iteratively inverted to WGS84"
    )
    for code in ("341204", "429004", "429005", "429006", "429021")
}


def read_audited_coordinates() -> dict[str, tuple[float, float]]:
    """Load the exact seven points from the independent source audit."""
    table = pd.read_csv(COORDINATE_AUDIT, dtype={"adcode": str})
    table["adcode"] = table["adcode"].str.zfill(6)
    expected = set(METHODS)
    observed = set(table["adcode"])
    assert observed == expected, (sorted(expected - observed), sorted(observed - expected))
    assert table["adcode"].is_unique
    assert table[["final_lon", "final_lat"]].notna().all(axis=None)
    return {
        row.adcode: (float(row.final_lon), float(row.final_lat))
        for row in table.itertuples(index=False)
    }
METHODS.update(
    {
        "370211": (
            "fixed pooled median of 722 valid 2006-2012 raw land-record coordinates; "
            "source coordinate datum is not explicitly documented"
        ),
        "370284": (
            "fixed pooled median of 1,074 valid 2006-2012 raw land-record coordinates; "
            "source coordinate datum is not explicitly documented"
        ),
    }
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def build(
    source: Path,
    output: Path,
    coordinates: dict[str, tuple[float, float]],
) -> tuple[pd.DataFrame, dict]:
    original = pd.read_csv(source, dtype={"Code": str})
    corrected = original.copy()
    audit_rows: list[dict] = []
    for code, (lon, lat) in coordinates.items():
        mask = corrected["Code"].eq(code)
        assert int(mask.sum()) == 14, (source, code, int(mask.sum()))
        old = corrected.loc[mask, ["Lon", "Lai"]].drop_duplicates()
        assert len(old) == 1, (source, code, old)
        corrected.loc[mask, "Lon"] = lon
        corrected.loc[mask, "Lai"] = lat
        audit_rows.append(
            {
                "Dataset": source.name,
                "Code": code,
                "OldLon": float(old.iloc[0]["Lon"]),
                "OldLai": float(old.iloc[0]["Lai"]),
                "FinalLon": lon,
                "FinalLai": lat,
                "RowsChanged": int(mask.sum()),
                "Method": METHODS[code],
            }
        )
    changed = original[["Lon", "Lai"]].ne(corrected[["Lon", "Lai"]]).any(axis=1)
    assert int(changed.sum()) == 14 * len(coordinates)
    noncoords = [column for column in original.columns if column not in {"Lon", "Lai"}]
    pd.testing.assert_frame_equal(original[noncoords], corrected[noncoords], check_exact=True)
    coordinate_counts = corrected.groupby("Code")[["Lon", "Lai"]].nunique(dropna=False)
    assert not (coordinate_counts > 1).any(axis=None)
    assert corrected.loc[corrected["Code"].isin(coordinates), ["Lon", "Lai"]].notna().all(axis=None)

    output.parent.mkdir(parents=True, exist_ok=True)
    corrected.to_csv(output, index=False)
    reread = pd.read_csv(output, dtype={"Code": str})
    assert len(reread) == len(original)
    pd.testing.assert_frame_equal(
        corrected[noncoords], reread[noncoords], check_exact=True, check_dtype=False
    )
    np.testing.assert_allclose(
        corrected[["Lon", "Lai"]].to_numpy(float),
        reread[["Lon", "Lai"]].to_numpy(float),
        rtol=0,
        atol=1e-12,
    )
    return pd.DataFrame(audit_rows), {
        "source": str(source),
        "source_sha256": sha256(source),
        "output": str(output),
        "output_sha256": sha256(output),
        "rows": int(len(corrected)),
        "counties": int(corrected["Code"].nunique()),
        "coordinate_rows_changed": int(changed.sum()),
        "non_coordinate_columns_exact_before_write": True,
        "non_coordinate_columns_exact_after_roundtrip": True,
    }


def main() -> None:
    coordinates = read_audited_coordinates()
    data_dir = FINAL / "data"
    audits: list[pd.DataFrame] = []
    manifests: dict[str, dict] = {}
    outputs = {
        "standardized": data_dir / "full_experiment_panel_std_coordinate_corrected.csv",
        "unstandardized": data_dir / "full_experiment_panel_coordinate_corrected.csv",
    }
    for label, source in INPUTS.items():
        audit, manifest = build(source, outputs[label], coordinates)
        audits.append(audit)
        manifests[label] = manifest
    audit = pd.concat(audits, ignore_index=True)
    audit_path = data_dir / "coordinate_replacement_audit.csv"
    audit.to_csv(audit_path, index=False)
    manifest = {
        "status": "passed",
        "scope": "isolated final copies; no existing metric-final or source file modified",
        "coordinate_count": len(coordinates),
        "fixed_location_rule": (
            "one coordinate per analysis code for every year; pooled multi-year "
            "centres used instead of time-varying transaction medians"
        ),
        "coordinates": {
            code: {"lon": lon, "lat": lat, "method": METHODS[code]}
            for code, (lon, lat) in coordinates.items()
        },
        "independent_coordinate_source_audit": {
            "path": str(COORDINATE_AUDIT),
            "sha256": sha256(COORDINATE_AUDIT),
        },
        "inputs_and_outputs": manifests,
        "audit": {"path": str(audit_path), "sha256": sha256(audit_path)},
        "limitations": [
            "The AMap boundary source is explicitly GCJ-02 despite an EPSG:4326 tag; coordinates use an iterative numerical inverse of the standard transform.",
            "The raw land-record coordinate columns lack explicit CRS/datum metadata.",
            "Coordinate correction does not resolve whether post-merger Jiaonan records in 2013-2014 should be recoded, aggregated, or excluded.",
        ],
    }
    manifest_path = data_dir / "coordinate_corrected_input_manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(audit.to_string(index=False))
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
