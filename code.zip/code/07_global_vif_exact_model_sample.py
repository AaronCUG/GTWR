#!/usr/bin/env python3
"""Recompute ordinary VIFs on the exact final A_main GTWR sample.

This audit intentionally uses the fifteen continuous predictors retained in
the final metric GTWR.  It filters on the same dependent variable, coordinate,
time, and predictor complete cases as ``01_run_gtwr_metric.py`` before
computing VIF = diag(inv(correlation matrix)).
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path("/Users/lizhaojie/Desktop/working/gtwr_metric_v15_20260726")
INPUT = Path(
    "/Users/lizhaojie/Desktop/working/land_redevelopment_rerun_20260725/"
    "data/full_experiment_panel_std_supplemented.csv"
)
OUTDIR = ROOT / "global_vif_exact_model_sample"
X_COLS = [
    "X1", "X2", "TRDEP", "X7", "RESH", "X16", "X9", "X10", "X11",
    "X13", "X14", "X3", "X4", "X8", "X6",
]
FACTOR_META = {
    "X1": ("LF", "Land finance"),
    "X2": ("FE", "Fiscal expenditure"),
    "TRDEP": ("TRD", "Transfer dependence"),
    "X7": ("BFL", "Bank loans"),
    "RESH": ("RES", "Real-estate land-supply share"),
    "X16": ("PEY", "Year-end population"),
    "X9": ("CGT", "Retail sales"),
    "X10": ("PGDP", "GDP per capita"),
    "X11": ("IEC", "Industrial firms"),
    "X13": ("SIP", "Secondary-industry share"),
    "X14": ("TIP", "Tertiary-industry share"),
    "X3": ("ETD", "Development zones"),
    "X4": ("AAP", "Allocated/agreement land share"),
    "X8": ("BAL", "Auctioned land share"),
    "X6": ("FAI", "Fixed-asset investment"),
}
MODEL_FILTER_COLS = ["URP_clean", "Lon", "Lai", "Year"] + X_COLS


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=INPUT)
    parser.add_argument("--output-dir", type=Path, default=OUTDIR)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    panel = pd.read_csv(args.input, dtype={"Code": str})
    sample = (
        panel[MODEL_FILTER_COLS]
        .replace([np.inf, -np.inf], np.nan)
        .dropna()
        .reset_index(drop=True)
    )
    assert len(sample) == 27_299
    corr = np.corrcoef(sample[X_COLS].to_numpy(float), rowvar=False)
    vifs = np.diag(np.linalg.inv(corr))
    table = pd.DataFrame(
        {
            "Model": "A_main_metric_final",
            "N_complete": len(sample),
            "Variable": X_COLS,
            "Abbr": [FACTOR_META[col][0] for col in X_COLS],
            "EngLabel": [FACTOR_META[col][1] for col in X_COLS],
            "VIF": vifs,
        }
    )
    output = args.output_dir / "global_vif_A_main_exact_sample.csv"
    table.to_csv(output, index=False)
    assert table["Variable"].nunique() == 15
    assert np.isfinite(table["VIF"]).all()
    maximum = table.loc[table["VIF"].idxmax()]
    manifest = {
        "status": "passed",
        "input": str(args.input),
        "input_sha256": sha256(args.input),
        "sample_definition": (
            "Complete cases on URP_clean, Lon, Lai, Year and the fifteen "
            "continuous predictors used by final A_main metric GTWR"
        ),
        "n": int(len(sample)),
        "predictor_count": int(len(X_COLS)),
        "formula": "diag(inv(Pearson predictor correlation matrix))",
        "maximum": {
            "variable": str(maximum["Variable"]),
            "abbr": str(maximum["Abbr"]),
            "label": str(maximum["EngLabel"]),
            "vif": float(maximum["VIF"]),
        },
        "output": str(output),
        "output_sha256": sha256(output),
    }
    manifest_path = args.output_dir / "global_vif_manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(table.to_string(index=False))
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
