#!/usr/bin/env python3
"""Compare unmasked and joint-CN+VDP-masked factor EHSA outputs."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import spearmanr


FACTORS = (
    "LF", "FE", "TRD", "BFL", "RES", "PEY", "CGT", "PGDP",
    "IEC", "SIP", "TIP", "ETD", "AAP", "BAL", "FAI",
)
NO_PATTERN = "No Pattern Detected"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def jenks_highest_lower(values: np.ndarray) -> float:
    values = np.sort(np.asarray(values, dtype=float))
    best: tuple[float, float] | None = None
    for i in range(1, len(values) - 1):
        for j in range(i + 1, len(values)):
            sse = (
                np.var(values[:i]) * i
                + np.var(values[i:j]) * (j - i)
                + np.var(values[j:]) * (len(values) - j)
            )
            if best is None or sse < best[0]:
                best = (float(sse), float(values[j]))
    assert best is not None
    return best[1]


def read(path: Path) -> pd.DataFrame:
    frame = pd.read_csv(path, dtype={"CODE": str})[["CODE", "PATTERN", "CATEGORY"]]
    frame["CODE"] = frame["CODE"].str.replace(r"\.0$", "", regex=True)
    assert not frame["CODE"].duplicated().any()
    return frame


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--unmasked-dir", type=Path, required=True)
    parser.add_argument("--masked-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    share_rows: list[dict] = []
    agreement_rows: list[dict] = []
    inputs: dict[str, dict] = {}
    for factor in FACTORS:
        upath = args.unmasked_dir / f"ehsa_{factor}.csv"
        mpath = args.masked_dir / f"ehsa_{factor}.csv"
        u, m = read(upath), read(mpath)
        inputs[factor] = {
            "unmasked": {"path": str(upath), "sha256": sha256(upath)},
            "masked": {"path": str(mpath), "sha256": sha256(mpath)},
        }
        ushare = float(u["PATTERN"].ne(NO_PATTERN).mean())
        mshare = float(m["PATTERN"].ne(NO_PATTERN).mean())
        common = u.merge(m, on="CODE", suffixes=("_unmasked", "_masked"), how="inner")
        union_count = len(set(u["CODE"]) | set(m["CODE"]))
        exact = common["PATTERN_unmasked"].eq(common["PATTERN_masked"])
        status_exact = (
            common["PATTERN_unmasked"].ne(NO_PATTERN)
            .eq(common["PATTERN_masked"].ne(NO_PATTERN))
        )
        share_rows.append(
            {
                "factor": factor,
                "unmasked_n": len(u),
                "unmasked_patterned": int(u["PATTERN"].ne(NO_PATTERN).sum()),
                "unmasked_share": ushare,
                "masked_n": len(m),
                "masked_patterned": int(m["PATTERN"].ne(NO_PATTERN).sum()),
                "masked_share": mshare,
                "share_change_pp": (mshare - ushare) * 100,
            }
        )
        agreement_rows.append(
            {
                "factor": factor,
                "unmasked_n": len(u),
                "masked_n": len(m),
                "common_n": len(common),
                "dropped_from_masked_n": len(u) - len(common),
                "pattern_exact_common_n": int(exact.sum()),
                "pattern_exact_common_pct": float(exact.mean() * 100),
                "pattern_exact_union_pct_treat_dropped_as_nonmatch": float(exact.sum() / union_count * 100),
                "pattern_status_exact_common_n": int(status_exact.sum()),
                "pattern_status_exact_common_pct": float(status_exact.mean() * 100),
            }
        )

    shares = pd.DataFrame(share_rows)
    shares["unmasked_rank"] = shares["unmasked_share"].rank(method="min", ascending=False).astype(int)
    shares["masked_rank"] = shares["masked_share"].rank(method="min", ascending=False).astype(int)
    shares = shares.sort_values("unmasked_rank").reset_index(drop=True)
    rho, pvalue = spearmanr(shares["unmasked_share"], shares["masked_share"])
    unmasked_jenks = jenks_highest_lower(shares["unmasked_share"].to_numpy())
    masked_jenks = jenks_highest_lower(shares["masked_share"].to_numpy())
    share_path = args.output_dir / "factor_share_rank_comparison.csv"
    agreement_path = args.output_dir / "pattern_agreement_by_factor.csv"
    shares.to_csv(share_path, index=False)
    pd.DataFrame(agreement_rows).to_csv(agreement_path, index=False)
    manifest = {
        "status": "passed",
        "spearman_share_rho": float(rho),
        "spearman_p_two_sided": float(pvalue),
        "unmasked_n": int(shares["unmasked_n"].iloc[0]),
        "masked_n": int(shares["masked_n"].iloc[0]),
        "dropped_counties": int(shares["unmasked_n"].iloc[0] - shares["masked_n"].iloc[0]),
        "unmasked_pass30": shares.loc[shares["unmasked_share"].ge(.30), "factor"].tolist(),
        "masked_pass30": shares.loc[shares["masked_share"].ge(.30), "factor"].tolist(),
        "unmasked_jenks_highest_lower": unmasked_jenks,
        "unmasked_jenks_highest_members": shares.loc[shares["unmasked_share"].ge(unmasked_jenks), "factor"].tolist(),
        "masked_jenks_highest_lower": masked_jenks,
        "masked_jenks_highest_members": shares.loc[shares["masked_share"].ge(masked_jenks), "factor"].tolist(),
        "inputs": inputs,
        "outputs": {
            "factor_share_rank_comparison.csv": sha256(share_path),
            "pattern_agreement_by_factor.csv": sha256(agreement_path),
        },
    }
    manifest_path = args.output_dir / "comparison_manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(shares.to_string(index=False))
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
